lightweight.mtp - a very fast MTP potential
test.mtp - an MTP potential with slightly more basis functions
